--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE poo_ii_proj1;
--
-- Name: poo_ii_proj1; Type: DATABASE; Schema: -; Owner: guilherme
--

CREATE DATABASE poo_ii_proj1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE poo_ii_proj1 OWNER TO guilherme;

\connect poo_ii_proj1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agendamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agendamento (
    id_colaborador bigint NOT NULL,
    id_estacao bigint NOT NULL,
    id_cliente bigint NOT NULL,
    id_servico bigint NOT NULL,
    dat date NOT NULL,
    hora time without time zone NOT NULL
);


ALTER TABLE public.agendamento OWNER TO postgres;

--
-- Name: atendimento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atendimento (
    valorfinal double precision NOT NULL,
    id_colaborador bigint NOT NULL,
    id_estacao bigint NOT NULL,
    id_cliente bigint NOT NULL,
    id_servico bigint NOT NULL,
    dat date NOT NULL,
    hora time without time zone NOT NULL
);


ALTER TABLE public.atendimento OWNER TO postgres;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id_cliente integer NOT NULL,
    nome character varying(255) NOT NULL,
    sobrenome character varying(255) NOT NULL,
    senha character varying(255) NOT NULL,
    dataintegracao date NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_id_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_id_cliente_seq OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_id_cliente_seq OWNED BY public.cliente.id_cliente;


--
-- Name: colaborador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colaborador (
    id_colaborador integer NOT NULL,
    nome character varying(255) NOT NULL,
    sobrenome character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    senha character varying(255) NOT NULL,
    cargo character varying(255) NOT NULL,
    dataintegracao date NOT NULL
);


ALTER TABLE public.colaborador OWNER TO postgres;

--
-- Name: colaborador_id_colaborador_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colaborador_id_colaborador_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colaborador_id_colaborador_seq OWNER TO postgres;

--
-- Name: colaborador_id_colaborador_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colaborador_id_colaborador_seq OWNED BY public.colaborador.id_colaborador;


--
-- Name: escala; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.escala (
    id_colaborador bigint NOT NULL,
    id_estacao bigint NOT NULL,
    dat date NOT NULL,
    hora time without time zone NOT NULL
);


ALTER TABLE public.escala OWNER TO postgres;

--
-- Name: estacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estacao (
    id_estacao integer NOT NULL,
    nome character varying(255) NOT NULL
);


ALTER TABLE public.estacao OWNER TO postgres;

--
-- Name: estacao_id_estacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estacao_id_estacao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estacao_id_estacao_seq OWNER TO postgres;

--
-- Name: estacao_id_estacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estacao_id_estacao_seq OWNED BY public.estacao.id_estacao;


--
-- Name: horario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.horario (
    dat date NOT NULL,
    hora time without time zone NOT NULL
);


ALTER TABLE public.horario OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    id_produto integer NOT NULL,
    nome character varying(255) NOT NULL,
    marca character varying(255) NOT NULL,
    descricao character varying(255),
    quantidade double precision DEFAULT '0'::double precision NOT NULL
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_id_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_id_produto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_id_produto_seq OWNER TO postgres;

--
-- Name: produto_id_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_id_produto_seq OWNED BY public.produto.id_produto;


--
-- Name: servico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servico (
    id_servico integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao character varying(255) NOT NULL,
    valor double precision NOT NULL,
    disponibilidade character varying(255) NOT NULL
);


ALTER TABLE public.servico OWNER TO postgres;

--
-- Name: servico_id_servico_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.servico_id_servico_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servico_id_servico_seq OWNER TO postgres;

--
-- Name: servico_id_servico_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.servico_id_servico_seq OWNED BY public.servico.id_servico;


--
-- Name: servprod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servprod (
    id_servico bigint NOT NULL,
    id_produto bigint NOT NULL
);


ALTER TABLE public.servprod OWNER TO postgres;

--
-- Name: tel_cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tel_cliente (
    id_cliente bigint NOT NULL,
    numero character varying(11) NOT NULL,
    nome_cliente character varying(255) NOT NULL
);


ALTER TABLE public.tel_cliente OWNER TO postgres;

--
-- Name: tel_colaborador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tel_colaborador (
    id_colaborador bigint NOT NULL,
    numero character varying(11) NOT NULL,
    nome_colaborador character varying(255) NOT NULL
);


ALTER TABLE public.tel_colaborador OWNER TO postgres;

--
-- Name: temp_servico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp_servico (
    id_servico bigint NOT NULL,
    hora character varying(2) NOT NULL,
    minuto character varying(2) NOT NULL
);


ALTER TABLE public.temp_servico OWNER TO postgres;

--
-- Name: cliente id_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id_cliente SET DEFAULT nextval('public.cliente_id_cliente_seq'::regclass);


--
-- Name: colaborador id_colaborador; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador ALTER COLUMN id_colaborador SET DEFAULT nextval('public.colaborador_id_colaborador_seq'::regclass);


--
-- Name: estacao id_estacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estacao ALTER COLUMN id_estacao SET DEFAULT nextval('public.estacao_id_estacao_seq'::regclass);


--
-- Name: produto id_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN id_produto SET DEFAULT nextval('public.produto_id_produto_seq'::regclass);


--
-- Name: servico id_servico; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico ALTER COLUMN id_servico SET DEFAULT nextval('public.servico_id_servico_seq'::regclass);


--
-- Data for Name: agendamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agendamento (id_colaborador, id_estacao, id_cliente, id_servico, dat, hora) FROM stdin;
\.
COPY public.agendamento (id_colaborador, id_estacao, id_cliente, id_servico, dat, hora) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: atendimento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atendimento (valorfinal, id_colaborador, id_estacao, id_cliente, id_servico, dat, hora) FROM stdin;
\.
COPY public.atendimento (valorfinal, id_colaborador, id_estacao, id_cliente, id_servico, dat, hora) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id_cliente, nome, sobrenome, senha, dataintegracao) FROM stdin;
\.
COPY public.cliente (id_cliente, nome, sobrenome, senha, dataintegracao) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: colaborador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colaborador (id_colaborador, nome, sobrenome, email, senha, cargo, dataintegracao) FROM stdin;
\.
COPY public.colaborador (id_colaborador, nome, sobrenome, email, senha, cargo, dataintegracao) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: escala; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.escala (id_colaborador, id_estacao, dat, hora) FROM stdin;
\.
COPY public.escala (id_colaborador, id_estacao, dat, hora) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: estacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estacao (id_estacao, nome) FROM stdin;
\.
COPY public.estacao (id_estacao, nome) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: horario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.horario (dat, hora) FROM stdin;
\.
COPY public.horario (dat, hora) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (id_produto, nome, marca, descricao, quantidade) FROM stdin;
\.
COPY public.produto (id_produto, nome, marca, descricao, quantidade) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: servico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servico (id_servico, nome, descricao, valor, disponibilidade) FROM stdin;
\.
COPY public.servico (id_servico, nome, descricao, valor, disponibilidade) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: servprod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servprod (id_servico, id_produto) FROM stdin;
\.
COPY public.servprod (id_servico, id_produto) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: tel_cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tel_cliente (id_cliente, numero, nome_cliente) FROM stdin;
\.
COPY public.tel_cliente (id_cliente, numero, nome_cliente) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: tel_colaborador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tel_colaborador (id_colaborador, numero, nome_colaborador) FROM stdin;
\.
COPY public.tel_colaborador (id_colaborador, numero, nome_colaborador) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: temp_servico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp_servico (id_servico, hora, minuto) FROM stdin;
\.
COPY public.temp_servico (id_servico, hora, minuto) FROM '$$PATH$$/3426.dat';

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_id_cliente_seq', 5, true);


--
-- Name: colaborador_id_colaborador_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colaborador_id_colaborador_seq', 3, true);


--
-- Name: estacao_id_estacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estacao_id_estacao_seq', 3, true);


--
-- Name: produto_id_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_id_produto_seq', 8, true);


--
-- Name: servico_id_servico_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servico_id_servico_seq', 1, false);


--
-- Name: agendamento agendamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_pkey PRIMARY KEY (dat, hora);


--
-- Name: atendimento atendimento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_pkey PRIMARY KEY (dat, hora);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente);


--
-- Name: colaborador colaborador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador
    ADD CONSTRAINT colaborador_pkey PRIMARY KEY (id_colaborador);


--
-- Name: escala escala_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escala
    ADD CONSTRAINT escala_pkey PRIMARY KEY (dat, hora);


--
-- Name: estacao estacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estacao
    ADD CONSTRAINT estacao_pkey PRIMARY KEY (id_estacao);


--
-- Name: horario horario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.horario
    ADD CONSTRAINT horario_pkey PRIMARY KEY (dat, hora);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (id_produto);


--
-- Name: servico servico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico
    ADD CONSTRAINT servico_pkey PRIMARY KEY (id_servico);


--
-- Name: servprod servprod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servprod
    ADD CONSTRAINT servprod_pkey PRIMARY KEY (id_servico, id_produto);


--
-- Name: tel_cliente tel_cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tel_cliente
    ADD CONSTRAINT tel_cliente_pkey PRIMARY KEY (id_cliente, numero);


--
-- Name: tel_colaborador tel_colaborador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tel_colaborador
    ADD CONSTRAINT tel_colaborador_pkey PRIMARY KEY (id_colaborador, numero);


--
-- Name: temp_servico temp_servico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp_servico
    ADD CONSTRAINT temp_servico_pkey PRIMARY KEY (id_servico);


--
-- Name: agendamento agendamento_dat_hora_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_dat_hora_fkey FOREIGN KEY (dat, hora) REFERENCES public.horario(dat, hora);


--
-- Name: agendamento agendamento_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


--
-- Name: agendamento agendamento_id_colaborador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_id_colaborador_fkey FOREIGN KEY (id_colaborador) REFERENCES public.colaborador(id_colaborador);


--
-- Name: agendamento agendamento_id_estacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_id_estacao_fkey FOREIGN KEY (id_estacao) REFERENCES public.estacao(id_estacao);


--
-- Name: agendamento agendamento_id_servico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agendamento
    ADD CONSTRAINT agendamento_id_servico_fkey FOREIGN KEY (id_servico) REFERENCES public.servico(id_servico);


--
-- Name: atendimento atendimento_dat_hora_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_dat_hora_fkey FOREIGN KEY (dat, hora) REFERENCES public.horario(dat, hora);


--
-- Name: atendimento atendimento_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


--
-- Name: atendimento atendimento_id_colaborador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_id_colaborador_fkey FOREIGN KEY (id_colaborador) REFERENCES public.colaborador(id_colaborador);


--
-- Name: atendimento atendimento_id_estacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_id_estacao_fkey FOREIGN KEY (id_estacao) REFERENCES public.estacao(id_estacao);


--
-- Name: atendimento atendimento_id_servico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimento
    ADD CONSTRAINT atendimento_id_servico_fkey FOREIGN KEY (id_servico) REFERENCES public.servico(id_servico);


--
-- Name: escala escala_dat_hora_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escala
    ADD CONSTRAINT escala_dat_hora_fkey FOREIGN KEY (dat, hora) REFERENCES public.horario(dat, hora);


--
-- Name: escala escala_id_colaborador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escala
    ADD CONSTRAINT escala_id_colaborador_fkey FOREIGN KEY (id_colaborador) REFERENCES public.colaborador(id_colaborador);


--
-- Name: escala escala_id_estacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.escala
    ADD CONSTRAINT escala_id_estacao_fkey FOREIGN KEY (id_estacao) REFERENCES public.estacao(id_estacao);


--
-- Name: tel_cliente fk_tel_cliente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tel_cliente
    ADD CONSTRAINT fk_tel_cliente FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


--
-- Name: tel_colaborador fk_tel_colaborador; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tel_colaborador
    ADD CONSTRAINT fk_tel_colaborador FOREIGN KEY (id_colaborador) REFERENCES public.colaborador(id_colaborador);


--
-- Name: temp_servico fk_temp_servico; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp_servico
    ADD CONSTRAINT fk_temp_servico FOREIGN KEY (id_servico) REFERENCES public.servico(id_servico);


--
-- Name: servprod servprod_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servprod
    ADD CONSTRAINT servprod_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES public.produto(id_produto);


--
-- Name: servprod servprod_id_servico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servprod
    ADD CONSTRAINT servprod_id_servico_fkey FOREIGN KEY (id_servico) REFERENCES public.servico(id_servico);


--
-- PostgreSQL database dump complete
--

